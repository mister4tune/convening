export const security = {
  csrf: false,
};
